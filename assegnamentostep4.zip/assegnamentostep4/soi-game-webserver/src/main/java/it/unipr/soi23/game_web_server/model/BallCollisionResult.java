package it.unipr.soi23.game_web_server.model;

public enum BallCollisionResult {
    LEFT_TEAM_POINT, //
    RIGHT_TEAM_POINT, //
}
