package it.unipr.soi23.game_web_server.service;

import java.util.Map;

public interface Soi23GameWebServerRepoViewService {

    Map<String, Object> getRepoMap();
}
