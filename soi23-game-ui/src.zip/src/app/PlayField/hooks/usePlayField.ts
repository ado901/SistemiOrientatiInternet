import {
    KeyboardEvent,
    useCallback,
    useEffect,
    useMemo,
    useRef,
    useState
} from 'react'
import {
    BallAnimation,
    PlayerDirection,
    PlayerPosition,
    PlayerTeam,
} from '../../utils/interfaces'
import {
    BALL_BASE_SVG_PROPS,
    INITIAL_BALL_DIRECTION,
    INITIAL_BALL_POS,
    INITIAL_PLAYER_POS_Y,
} from '../../utils/const'
import Arena from '../../utils/Arena'
import Ball from '../../utils/Ball'
import Player from '../../utils/Player'

interface BallProps extends React.SVGProps<SVGCircleElement> {
    style: React.CSSProperties,
}

export default function usePlayField() {
    const [isPlaying, setIsPlaying] = useState(false)
    const [playerLeftPosY, setPlayerLeftPosY] = useState(INITIAL_PLAYER_POS_Y)
    const [playerRightPosY, setPlayerRightPosY] = useState(INITIAL_PLAYER_POS_Y)
    const [ballAnimation, setBallAnimation] = useState<BallAnimation | null>(null)

    const arenaRef = useRef<Arena>(new Arena(
        new Ball(INITIAL_BALL_POS, INITIAL_BALL_DIRECTION, setBallAnimation),
        [
            new Player({ team: PlayerTeam.LEFT, y: INITIAL_PLAYER_POS_Y }, setPlayerLeftPosY),
            new Player({ team: PlayerTeam.RIGHT, y: INITIAL_PLAYER_POS_Y }, setPlayerRightPosY),
            // You can add as many players as you want
        ]
    ))

    const ballProps: BallProps = useMemo(() => {
        const customStyle: React.CSSProperties = {}
        if (ballAnimation !== null) {
            document.documentElement.style.setProperty('--ball-end-y', `${ballAnimation.endY}`)
            document.documentElement.style.setProperty('--ball-end-x', `${ballAnimation.endX}`)
            customStyle.animationName = 'ballAnimation'
            customStyle.animationTimingFunction = 'linear'
            customStyle.animationFillMode = 'forwards'
            customStyle.animationDuration = `${ballAnimation.time}s`
            if (!isPlaying) {
                customStyle.animationPlayState = 'paused'
            }
        } else {
            customStyle.visibility = 'hidden'
        }
        return {
            style: customStyle,
            ...BALL_BASE_SVG_PROPS,
            cx: ballAnimation?.startX,
            cy: ballAnimation?.startY,
        }
    }, [ballAnimation, isPlaying])

    const playerPositions: PlayerPosition[] = useMemo(() => ([
        { team: PlayerTeam.LEFT, y: playerLeftPosY },
        { team: PlayerTeam.RIGHT, y: playerRightPosY },
    ]), [playerLeftPosY, playerRightPosY])

    const handleKeyDown = useCallback(({ key }: KeyboardEvent) => {
        /* TODO
        Map the key so that you can:
            - set the moving direction of every player
            - start/stop the game
        */
            if (key === 'ArrowUp' || key === 'ArrowDown') {
                // Reset the moving direction of the right player
                arenaRef.current.getPlayer(PlayerTeam.RIGHT)?.setDirection((key === 'ArrowDown')? PlayerDirection.Down : PlayerDirection.Up)
            }
            if (key === 'w' || key === 's') {
                // Reset the moving direction of the left player
                arenaRef.current.getPlayer(PlayerTeam.LEFT)?.setDirection((key === 's')? PlayerDirection.Down : PlayerDirection.Up)
            }
            if (key === ' ') {
                // Start/stop the game
                 isPlaying?arenaRef.current.pause():arenaRef.current.play()
                 setIsPlaying(!isPlaying)
     
            }
    }, [setIsPlaying, isPlaying])

    const handleKeyUp = useCallback(({ key }: KeyboardEvent) => {
        /* TODO
        Map the key so that you can reset the moving direction
        of the corresponding player.
        Be aware that the user could have already pressed the key
        corresponding to the opposite player direction
        */
       if (key === 'ArrowUp' && arenaRef.current.getPlayer(PlayerTeam.RIGHT)?.getDirection() === PlayerDirection.Up) {
        // Reset the moving direction of the right player
        arenaRef.current.getPlayer(PlayerTeam.RIGHT)?.setDirection(PlayerDirection.Hold)
       }
       if (key === 'ArrowDown' && arenaRef.current.getPlayer(PlayerTeam.RIGHT)?.getDirection() === PlayerDirection.Down) {
        // Reset the moving direction of the right player
        arenaRef.current.getPlayer(PlayerTeam.RIGHT)?.setDirection(PlayerDirection.Hold)
       }
       if (key === 'w' && arenaRef.current.getPlayer(PlayerTeam.LEFT)?.getDirection() === PlayerDirection.Up) {
        // Reset the moving direction of the left player
        arenaRef.current.getPlayer(PlayerTeam.LEFT)?.setDirection(PlayerDirection.Hold)
       }
       if (key === 's' && arenaRef.current.getPlayer(PlayerTeam.LEFT)?.getDirection() === PlayerDirection.Down) {
        // Reset the moving direction of the left player
        arenaRef.current.getPlayer(PlayerTeam.LEFT)?.setDirection(PlayerDirection.Hold)
       }
    }, [])

    const handleAnimationEnd = useCallback(() => {
        console.log('Animation ended')
        setBallAnimation(null)
        window.requestAnimationFrame(
            () => arenaRef.current.setBallAnimationEnded(true)
        )
    }, [])

    useEffect(() => {
        setBallAnimation(arenaRef.current.getBall().getAnimation())
        return () => {
            console.log('CLEANUP')
        }
    }, [])

    return {
        ballProps,
        playerPositions,
        handleKeyDown,
        handleKeyUp,
        handleAnimationEnd,
    }
}
