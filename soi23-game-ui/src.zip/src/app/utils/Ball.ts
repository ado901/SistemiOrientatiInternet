import Player from './Player'
import {
    PLAYFIELD_HEIGHT,
    BALL_RADIUS,
    BALL_SPEED,
    LEFT_TEAM_X,
    PLAYER_HEIGHT,
    RIGHT_TEAM_X,
} from './const'
import {
    BallAnimation,
    BallPosition,
    PlayerTeam
} from './interfaces'

const MIN_X = LEFT_TEAM_X + BALL_RADIUS
const MAX_X = RIGHT_TEAM_X - BALL_RADIUS
const MIN_Y = BALL_RADIUS
const MAX_Y = PLAYFIELD_HEIGHT - BALL_RADIUS
const SIN_COS_EPSILON = 0.01

export default class Ball {
    private animation: BallAnimation

    constructor(
        position: BallPosition,
        direction: number,
        private onChange: (ballAnimation: BallAnimation) => void
    ) {
        this.animation = this.retrieveNewAnimation(position, direction)
    }

    public getAnimation() {
        return this.animation
    }

    /**
     * To call only when last animation ended
     */
    public animate(players: Player[]) {
        const {
            startX,
            startY,
            endX,
            endY,
        } = this.animation

        // direction inversion because Y increase upward, while top downward
        let direction = Math.atan2(-endY + startY, endX - startX)

        // Collision detection with walls
        if (endY === MIN_Y || endY === MAX_Y) {
            direction *= -1
        }

        // Collision detection with players
        if (endX === MIN_X || endX === MAX_X) {
            const isHit = players.some((player) => {
                const playerPosition = player.getPosition()
                const playerPosX = playerPosition.team === PlayerTeam.LEFT
                    ? LEFT_TEAM_X
                    : RIGHT_TEAM_X
                const playerPosY = playerPosition.y

                if (Math.abs(playerPosX - endX) > BALL_RADIUS) {
                    return false
                }
                const deltaV = Math.abs(endY - playerPosY)
                const overlapV = deltaV <= BALL_RADIUS + PLAYER_HEIGHT / 2
                if (!overlapV) {
                    return false
                }
                if (deltaV <= PLAYER_HEIGHT / 2) {
                    // Horizontal collision
                    direction = (Math.PI - direction) % (2 * Math.PI)
                } else {
                    // Corner collision
                    const dY = endY > playerPosY
                        ? endY - (playerPosY + PLAYER_HEIGHT / 2)
                        : endY - (playerPosY - PLAYER_HEIGHT / 2)
                    const dX = endX - playerPosX
                    // Normal of the collision plane
                    direction = Math.atan2(-dY, dX)
                }
                return true
            })
            if (!isHit) {
                return
            }
        }

        this.animation = this.retrieveNewAnimation({ y: endY, x: endX }, direction)
        this.onChange(this.animation)
    }

    private retrieveNewAnimation(position: BallPosition, direction: number) {
        // Collision prevision
        const cos = Math.cos(direction)
        const sin = Math.sin(direction)

        let nextX
        let nextY
        if (Math.abs(sin) < SIN_COS_EPSILON) {
            nextX = cos > 0 ? MAX_X : MIN_X
            nextY = position.y
        } else if (Math.abs(cos) < SIN_COS_EPSILON) {
            nextX = position.x
            nextY = sin > 0 ? MIN_Y : MAX_Y
        } else {
            const m = Math.tan(-direction)
            const q = position.y - m * position.x
            // Y = mX + q

            const wallX = cos > 0 ? MAX_X : MIN_X
            const wallY = sin > 0 ? MIN_Y : MAX_Y

            const wallDistY = sin > 0
                ? position.y - MIN_Y
                : MAX_Y - position.y

            const intersectionY = m * wallX + q
            if (Math.abs(intersectionY - position.y) <= wallDistY) {
                nextX = wallX
                nextY = intersectionY
            } else {
                nextX = (wallY - q) / m
                nextY = wallY
            }
        }

        const collisionDistX = nextX - position.x
        const collisionDistY = nextY - position.y
        const collisionDist = Math.sqrt(collisionDistX * collisionDistX + collisionDistY * collisionDistY)
        const collisionTime = collisionDist / BALL_SPEED

        return {
            startX: position.x,
            startY: position.y,
            endX: nextX,
            endY: nextY,
            time: collisionTime,
        }
    }
}
